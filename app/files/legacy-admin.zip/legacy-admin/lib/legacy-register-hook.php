<?php

/**
 * @Package: WordPress Plugin
 * @Subpackage: Legacy - White Label WordPress Admin Theme
 * @Since: Legacy 1.0
 * @WordPress Version: 4.0 or above
 * This file is part of Legacy - White Label WordPress Admin Theme Plugin.
 */
//Activation Code
function legacy_admin_activation() {
    //global $wpdb;
    //add_option("legacy_admin_version", "1.0");
}

//Deactivation Code
function legacy_admin_deactivation() {

    /* 	
      delete_option('legacy_admin_version');
     */
}

?>