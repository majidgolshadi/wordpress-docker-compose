<?php

class Test_Avada_Dummy extends WP_UnitTestCase {

	public function test_tests_working() {
		$this->assertEquals( true, true );
	}

}
